# Portable Agent Workflow Template

This repository is a reusable starter for Copilot instructions, skills, prompts, and workflow logging.

## What It Contains

- `.github/copilot-instructions.md` for always-on repository guidance.
- `.github/skills/` for reusable agent skills.
- `.github/prompts/` for reusable slash-command prompts.
- `docs/NONSPECIFIC_SKILLS.md` as a portable workflow handbook.
- `logging/` for progress and commit history templates.
- `.githooks/pre-push` for optional push-triggered logging.

## How To Use It

1. Copy the repository into a new project.
2. Replace the generic guidance with project-specific architecture, build, and test details.
3. Keep the skill map and instruction surfaces in sync when skills change.
4. Add project-specific docs only after the reusable workflow is established.

## What To Customize First

1. `.github/copilot-instructions.md`
2. `.github/skills/SKILL_MAP.md`
3. Any project-specific prompt files you add later
4. The source-of-truth docs for the new project

## Notes

- This template is intentionally free of application code.
- Add a project-specific README, architecture docs, and tests in the target repository.
- If you publish the template publicly, add a license appropriate for reuse.